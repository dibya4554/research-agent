"""
DocumentIngestor — Handles ingestion of PDF and plain-text documents.

Pipeline:
  1. Load raw bytes → extract text (PyMuPDF for PDFs, decode for TXT)
  2. Chunk text using RecursiveCharacterTextSplitter
  3. Embed chunks using OpenAI Embeddings
  4. Upsert into persistent FAISS vector store
"""

import io
import fitz  # PyMuPDF
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from app.rag.vectorstore import VectorStoreManager
from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class DocumentIngestor:
    """
    Ingests uploaded documents into the FAISS vector store.
    Supports PDF and plain-text formats.
    """

    def __init__(self):
        self.vs_manager = VectorStoreManager()
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            separators=["\n\n", "\n", ". ", " ", ""],
        )

    # ── Public Methods ─────────────────────────────────────────────────────────

    def ingest(self, content: bytes, filename: str) -> int:
        """
        Full ingestion pipeline for a single document.

        Args:
            content:  Raw file bytes.
            filename: Original filename (used as source metadata).

        Returns:
            Number of chunks indexed into the vector store.
        """
        logger.info(f"Starting ingestion for: {filename}")

        if filename.lower().endswith(".pdf"):
            docs = self._load_pdf(content, filename)
        else:
            docs = self._load_text(content, filename)

        if not docs:
            logger.warning(f"No content extracted from {filename}.")
            return 0

        chunks = self.splitter.split_documents(docs)
        logger.info(f"Split into {len(chunks)} chunks.")

        self.vs_manager.upsert(chunks)
        return len(chunks)

    def clear(self):
        """Wipes the vector store."""
        self.vs_manager.clear()
        logger.info("Vector store cleared.")

    # ── Private Loaders ────────────────────────────────────────────────────────

    def _load_pdf(self, content: bytes, filename: str) -> list[Document]:
        """Extracts text from each page of a PDF using PyMuPDF."""
        docs = []
        try:
            pdf = fitz.open(stream=content, filetype="pdf")
            for page_num in range(len(pdf)):
                page = pdf[page_num]
                text = page.get_text("text").strip()
                if text:
                    docs.append(Document(
                        page_content=text,
                        metadata={"source": filename, "page": page_num + 1},
                    ))
            pdf.close()
            logger.info(f"Extracted {len(docs)} pages from {filename}.")
        except Exception as e:
            logger.error(f"PDF extraction failed: {e}")
        return docs

    def _load_text(self, content: bytes, filename: str) -> list[Document]:
        """Loads plain text files."""
        try:
            text = content.decode("utf-8", errors="ignore").strip()
            if text:
                return [Document(page_content=text, metadata={"source": filename})]
        except Exception as e:
            logger.error(f"Text loading failed: {e}")
        return []
