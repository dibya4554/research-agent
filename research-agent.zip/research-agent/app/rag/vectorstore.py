"""
VectorStoreManager — Manages a persistent FAISS vector store.

- Uses OpenAI text-embedding-3-small for embeddings.
- Persists the index to disk so it survives restarts.
- Thread-safe upsert using a simple file lock pattern.
"""

import os
import shutil
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document

from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)

VECTORSTORE_PATH = Path(settings.VECTORSTORE_DIR)


class VectorStoreManager:
    """
    Singleton-style manager for the FAISS vector store.
    Handles creation, persistence, upsert, and clearing.
    """

    _instance: FAISS | None = None

    def __init__(self):
        self.embeddings = OpenAIEmbeddings(
            model=settings.EMBEDDING_MODEL,
            api_key=settings.OPENAI_API_KEY,
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    def get_store(self) -> FAISS | None:
        """
        Returns the FAISS store — loads from disk if not in memory.
        Returns None if no documents have been ingested yet.
        """
        if VectorStoreManager._instance is not None:
            return VectorStoreManager._instance

        if VECTORSTORE_PATH.exists():
            logger.info("Loading FAISS index from disk...")
            try:
                VectorStoreManager._instance = FAISS.load_local(
                    str(VECTORSTORE_PATH),
                    self.embeddings,
                    allow_dangerous_deserialization=True,
                )
                logger.info("FAISS index loaded.")
                return VectorStoreManager._instance
            except Exception as e:
                logger.error(f"Failed to load FAISS index: {e}")

        logger.info("No FAISS index found. Vector store is empty.")
        return None

    def upsert(self, documents: list[Document]) -> None:
        """
        Adds new documents to the vector store.
        Creates the store if it doesn't exist yet.
        """
        if not documents:
            return

        store = self.get_store()
        if store is None:
            logger.info("Creating new FAISS index...")
            VectorStoreManager._instance = FAISS.from_documents(documents, self.embeddings)
        else:
            store.add_documents(documents)

        self._save()
        logger.info(f"Upserted {len(documents)} chunks into FAISS.")

    def clear(self) -> None:
        """Deletes the FAISS index from disk and resets the in-memory store."""
        VectorStoreManager._instance = None
        if VECTORSTORE_PATH.exists():
            shutil.rmtree(VECTORSTORE_PATH)
            logger.info("FAISS index deleted from disk.")

    # ── Private ────────────────────────────────────────────────────────────────

    def _save(self) -> None:
        """Persists the in-memory FAISS index to disk."""
        if VectorStoreManager._instance is not None:
            VECTORSTORE_PATH.mkdir(parents=True, exist_ok=True)
            VectorStoreManager._instance.save_local(str(VECTORSTORE_PATH))
            logger.info("FAISS index saved to disk.")
