"""
SynthesisAgent — Combines retrieved RAG chunks and web search results
into a coherent, well-structured research answer using an LLM.
"""

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


SYNTHESIS_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an expert research analyst. Using the provided context from documents 
and web search results, produce a comprehensive, well-structured answer to the research query.

Guidelines:
- Synthesise information from ALL provided sources.
- Highlight key findings, trends, and insights.
- If sources conflict, acknowledge the discrepancy.
- Use clear paragraphs. Do NOT use bullet points.
- Cite source references inline as [Source: <name>] where available.
- If context is insufficient, state what is known and what remains unclear.

Context from documents:
{doc_context}

Context from web search:
{web_context}
"""),
    ("human", "Research query: {query}"),
])


class SynthesisAgent:
    """
    Takes retrieved chunks and web snippets, feeds them to an LLM,
    and returns a comprehensive synthesised answer.
    """

    def __init__(self):
        self.llm = ChatOpenAI(
            model=settings.LLM_MODEL,
            temperature=0.3,
            api_key=settings.OPENAI_API_KEY,
        )
        self.chain = SYNTHESIS_PROMPT | self.llm

    def run(self, query: str, chunks: list[str], web_results: list[str]) -> str:
        """
        Synthesises an answer from retrieved context.

        Args:
            query:       The original research query.
            chunks:      Document chunks from the vector store.
            web_results: Snippets from web search.

        Returns:
            A synthesised answer string.
        """
        doc_context = "\n\n---\n\n".join(chunks) if chunks else "No documents retrieved."
        web_context = "\n\n".join(web_results) if web_results else "No web results available."

        try:
            response = self.chain.invoke({
                "query": query,
                "doc_context": doc_context,
                "web_context": web_context,
            })
            answer = response.content.strip()
            logger.info("Synthesis complete.")
            return answer
        except Exception as e:
            logger.error(f"Synthesis failed: {e}")
            return "Unable to synthesise an answer due to an internal error."
