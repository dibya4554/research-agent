"""
Research Orchestrator — LangGraph Multi-Agent Pipeline

Agents in the graph:
  1. PlannerAgent   → Decomposes the user query into sub-tasks
  2. RetrieverAgent → Fetches relevant chunks from FAISS vector store
  3. SearchAgent    → Optionally searches the web for recent information
  4. SynthesisAgent → Synthesises retrieved content into a coherent answer
  5. SummaryAgent   → Produces a concise executive summary
"""

import asyncio
from typing import TypedDict, Annotated, Sequence
import operator

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END

from app.agents.planner import PlannerAgent
from app.agents.retriever import RetrieverAgent
from app.agents.search import SearchAgent
from app.agents.synthesis import SynthesisAgent
from app.agents.summary import SummaryAgent
from app.utils.logger import get_logger

logger = get_logger(__name__)


# ── Shared State Schema ────────────────────────────────────────────────────────

class AgentState(TypedDict):
    query: str
    sub_tasks: list[str]
    retrieved_chunks: list[str]
    web_results: list[str]
    answer: str
    summary: str
    sources: list[str]
    agent_trace: Annotated[list[str], operator.add]   # append-only log
    max_sources: int
    include_summary: bool


# ── Orchestrator ───────────────────────────────────────────────────────────────

class ResearchOrchestrator:
    """
    Builds and compiles a LangGraph StateGraph that routes the query
    through specialised agents in a structured pipeline.
    """

    def __init__(self):
        self.planner   = PlannerAgent()
        self.retriever = RetrieverAgent()
        self.searcher  = SearchAgent()
        self.synthesis = SynthesisAgent()
        self.summariser = SummaryAgent()
        self.graph = self._build_graph()

    # ── Graph Construction ─────────────────────────────────────────────────────

    def _build_graph(self) -> StateGraph:
        graph = StateGraph(AgentState)

        graph.add_node("planner",   self._planner_node)
        graph.add_node("retriever", self._retriever_node)
        graph.add_node("searcher",  self._searcher_node)
        graph.add_node("synthesis", self._synthesis_node)
        graph.add_node("summary",   self._summary_node)

        graph.set_entry_point("planner")

        graph.add_edge("planner",   "retriever")
        graph.add_edge("retriever", "searcher")
        graph.add_edge("searcher",  "synthesis")

        # Conditionally run summary agent
        graph.add_conditional_edges(
            "synthesis",
            self._should_summarise,
            {"summarise": "summary", "skip": END},
        )
        graph.add_edge("summary", END)

        return graph.compile()

    # ── Node Wrappers ──────────────────────────────────────────────────────────

    def _planner_node(self, state: AgentState) -> AgentState:
        logger.info("PlannerAgent running...")
        sub_tasks = self.planner.run(state["query"])
        return {
            **state,
            "sub_tasks": sub_tasks,
            "agent_trace": [f"[Planner] Decomposed into {len(sub_tasks)} sub-tasks: {sub_tasks}"],
        }

    def _retriever_node(self, state: AgentState) -> AgentState:
        logger.info("RetrieverAgent running...")
        chunks, sources = self.retriever.run(
            sub_tasks=state["sub_tasks"],
            max_sources=state["max_sources"],
        )
        return {
            **state,
            "retrieved_chunks": chunks,
            "sources": sources,
            "agent_trace": [f"[Retriever] Retrieved {len(chunks)} chunks from vector store."],
        }

    def _searcher_node(self, state: AgentState) -> AgentState:
        logger.info("SearchAgent running...")
        web_results = self.searcher.run(query=state["query"])
        return {
            **state,
            "web_results": web_results,
            "agent_trace": [f"[Search] Found {len(web_results)} web results."],
        }

    def _synthesis_node(self, state: AgentState) -> AgentState:
        logger.info("SynthesisAgent running...")
        answer = self.synthesis.run(
            query=state["query"],
            chunks=state["retrieved_chunks"],
            web_results=state["web_results"],
        )
        return {
            **state,
            "answer": answer,
            "agent_trace": ["[Synthesis] Generated answer from retrieved context."],
        }

    def _summary_node(self, state: AgentState) -> AgentState:
        logger.info("SummaryAgent running...")
        summary = self.summariser.run(answer=state["answer"])
        return {
            **state,
            "summary": summary,
            "agent_trace": ["[Summary] Executive summary generated."],
        }

    # ── Conditional Edge ───────────────────────────────────────────────────────

    @staticmethod
    def _should_summarise(state: AgentState) -> str:
        return "summarise" if state.get("include_summary") else "skip"

    # ── Public Run Method ──────────────────────────────────────────────────────

    async def run(self, query: str, max_sources: int = 5, include_summary: bool = True) -> dict:
        initial_state: AgentState = {
            "query": query,
            "sub_tasks": [],
            "retrieved_chunks": [],
            "web_results": [],
            "answer": "",
            "summary": "",
            "sources": [],
            "agent_trace": ["[Orchestrator] Pipeline started."],
            "max_sources": max_sources,
            "include_summary": include_summary,
        }

        # LangGraph's sync invoke — wrap in executor for async FastAPI
        loop = asyncio.get_event_loop()
        final_state = await loop.run_in_executor(None, self.graph.invoke, initial_state)

        return {
            "query": final_state["query"],
            "answer": final_state["answer"],
            "sources": final_state["sources"],
            "summary": final_state.get("summary"),
            "agent_trace": final_state["agent_trace"],
        }
