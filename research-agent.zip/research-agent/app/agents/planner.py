"""
PlannerAgent — Decomposes a complex user query into focused sub-tasks
using an LLM with structured output parsing.
"""

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from pydantic import BaseModel, Field
from typing import List

from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class SubTaskList(BaseModel):
    sub_tasks: List[str] = Field(description="List of focused sub-tasks derived from the query.")


PLANNER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a research planning agent. Your job is to decompose a complex 
research query into 2–4 focused, specific sub-tasks that together fully answer the question.
Each sub-task should be independently searchable and non-overlapping.

Return ONLY valid JSON in this format:
{{"sub_tasks": ["sub-task 1", "sub-task 2", ...]}}"""),
    ("human", "Research query: {query}"),
])


class PlannerAgent:
    """
    Uses an LLM to break down the user's research query into
    specific sub-tasks for targeted retrieval and search.
    """

    def __init__(self):
        self.llm = ChatOpenAI(
            model=settings.LLM_MODEL,
            temperature=0,
            api_key=settings.OPENAI_API_KEY,
        )
        self.parser = JsonOutputParser(pydantic_object=SubTaskList)
        self.chain = PLANNER_PROMPT | self.llm | self.parser

    def run(self, query: str) -> list[str]:
        """
        Decomposes the query into sub-tasks.

        Args:
            query: The user's research question.

        Returns:
            List of sub-task strings.
        """
        try:
            result = self.chain.invoke({"query": query})
            sub_tasks = result.get("sub_tasks", [query])
            logger.info(f"Planner decomposed query into: {sub_tasks}")
            return sub_tasks
        except Exception as e:
            logger.warning(f"Planner failed, falling back to original query: {e}")
            return [query]
