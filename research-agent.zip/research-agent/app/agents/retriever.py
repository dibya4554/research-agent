"""
RetrieverAgent — Performs semantic similarity search over the FAISS
vector store for each sub-task and deduplicates retrieved chunks.
"""

from app.rag.vectorstore import VectorStoreManager
from app.utils.logger import get_logger

logger = get_logger(__name__)


class RetrieverAgent:
    """
    Retrieves the most relevant document chunks from the FAISS vector
    store for a list of sub-tasks, deduplicating by content hash.
    """

    def __init__(self):
        self.vs_manager = VectorStoreManager()

    def run(self, sub_tasks: list[str], max_sources: int = 5) -> tuple[list[str], list[str]]:
        """
        Searches the vector store for each sub-task and returns
        deduplicated chunks along with their source identifiers.

        Args:
            sub_tasks:   List of focused sub-task queries.
            max_sources: Max number of unique chunks to return in total.

        Returns:
            (chunks, sources) — parallel lists of text and source labels.
        """
        seen = set()
        chunks: list[str] = []
        sources: list[str] = []

        vectorstore = self.vs_manager.get_store()
        if vectorstore is None:
            logger.warning("Vector store is empty. Skipping retrieval.")
            return [], []

        per_task_k = max(1, max_sources // len(sub_tasks))

        for task in sub_tasks:
            try:
                docs = vectorstore.similarity_search(task, k=per_task_k)
                for doc in docs:
                    content_hash = hash(doc.page_content[:200])
                    if content_hash not in seen:
                        seen.add(content_hash)
                        chunks.append(doc.page_content)
                        source = doc.metadata.get("source", "unknown")
                        page   = doc.metadata.get("page", "")
                        sources.append(f"{source} (p.{page})" if page else source)
            except Exception as e:
                logger.error(f"Retrieval failed for sub-task '{task}': {e}")

        logger.info(f"Retrieved {len(chunks)} unique chunks across {len(sub_tasks)} sub-tasks.")
        return chunks[:max_sources], sources[:max_sources]
