"""
SummaryAgent — Produces a concise executive summary (3–5 sentences)
from the synthesised research answer.
"""

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


SUMMARY_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a precise summarisation assistant.
Condense the following research answer into a crisp executive summary of 3–5 sentences.
Focus on the most important findings and actionable insights only.
Do not introduce new information."""),
    ("human", "{answer}"),
])


class SummaryAgent:
    """
    Generates a brief executive summary from the full synthesised answer.
    Useful for quick consumption of long research responses.
    """

    def __init__(self):
        self.llm = ChatOpenAI(
            model=settings.LLM_MODEL,
            temperature=0.1,
            api_key=settings.OPENAI_API_KEY,
        )
        self.chain = SUMMARY_PROMPT | self.llm

    def run(self, answer: str) -> str:
        """
        Summarises the answer.

        Args:
            answer: Full synthesised research answer.

        Returns:
            A 3–5 sentence executive summary.
        """
        if not answer or len(answer) < 200:
            return answer  # too short to summarise

        try:
            response = self.chain.invoke({"answer": answer})
            summary = response.content.strip()
            logger.info("Summary generated.")
            return summary
        except Exception as e:
            logger.warning(f"Summary generation failed: {e}")
            return ""
