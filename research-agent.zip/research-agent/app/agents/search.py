"""
SearchAgent — Augments RAG retrieval with live web search results
using DuckDuckGo (no API key required) via LangChain tools.
"""

from langchain_community.tools import DuckDuckGoSearchRun
from app.utils.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)


class SearchAgent:
    """
    Uses DuckDuckGo search to fetch recent, publicly available
    information that may not be present in the local vector store.
    Web search can be disabled via settings.
    """

    def __init__(self):
        self.enabled = settings.ENABLE_WEB_SEARCH
        if self.enabled:
            self.search_tool = DuckDuckGoSearchRun()

    def run(self, query: str) -> list[str]:
        """
        Executes a web search for the given query.

        Args:
            query: The research query string.

        Returns:
            List of result snippet strings (empty if disabled or failed).
        """
        if not self.enabled:
            logger.info("Web search is disabled. Skipping SearchAgent.")
            return []

        try:
            raw_result = self.search_tool.run(query)
            # DuckDuckGoSearchRun returns a single string; split into chunks
            snippets = [s.strip() for s in raw_result.split("\n") if s.strip()]
            logger.info(f"Web search returned {len(snippets)} snippets.")
            return snippets[:5]  # cap at 5 snippets
        except Exception as e:
            logger.warning(f"Web search failed: {e}")
            return []
