"""
Research Assistant Agent — FastAPI Entry Point
Exposes the multi-agent RAG pipeline as a REST API.
"""

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uvicorn
import logging

from app.agents.orchestrator import ResearchOrchestrator
from app.rag.ingestor import DocumentIngestor
from app.utils.logger import get_logger

logger = get_logger(__name__)

app = FastAPI(
    title="Research Assistant Agent",
    description="Multi-agent RAG pipeline for intelligent research and summarization.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

orchestrator = ResearchOrchestrator()
ingestor = DocumentIngestor()


# ── Request / Response Models ──────────────────────────────────────────────────

class QueryRequest(BaseModel):
    query: str
    max_sources: Optional[int] = 5
    include_summary: Optional[bool] = True


class QueryResponse(BaseModel):
    query: str
    answer: str
    sources: list[str]
    summary: Optional[str] = None
    agent_trace: list[str]


class IngestResponse(BaseModel):
    status: str
    chunks_indexed: int
    document_name: str


# ── Routes ─────────────────────────────────────────────────────────────────────

@app.get("/health")
def health_check():
    """Health check endpoint for AWS ALB / CloudWatch."""
    return {"status": "healthy", "service": "research-agent"}


@app.post("/query", response_model=QueryResponse)
async def query_agent(request: QueryRequest):
    """
    Main endpoint: accepts a research query, runs the multi-agent pipeline,
    and returns an answer with sources and optional summary.
    """
    try:
        logger.info(f"Received query: {request.query}")
        result = await orchestrator.run(
            query=request.query,
            max_sources=request.max_sources,
            include_summary=request.include_summary,
        )
        return QueryResponse(**result)
    except Exception as e:
        logger.error(f"Query failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ingest", response_model=IngestResponse)
async def ingest_document(file: UploadFile = File(...)):
    """
    Upload a PDF or text document. It will be chunked, embedded,
    and stored in the FAISS vector store for retrieval.
    """
    if file.content_type not in ["application/pdf", "text/plain"]:
        raise HTTPException(status_code=400, detail="Only PDF and TXT files are supported.")
    try:
        content = await file.read()
        chunks_indexed = ingestor.ingest(content=content, filename=file.filename)
        return IngestResponse(
            status="success",
            chunks_indexed=chunks_indexed,
            document_name=file.filename,
        )
    except Exception as e:
        logger.error(f"Ingestion failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/vectorstore")
def clear_vectorstore():
    """Clear all indexed documents from the vector store."""
    ingestor.clear()
    return {"status": "Vector store cleared."}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
