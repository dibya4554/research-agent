"""
Application Configuration — loaded from environment variables / .env file.
"""

from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # ── LLM ───────────────────────────────────────────────────────────────────
    OPENAI_API_KEY:  str  = Field(..., env="OPENAI_API_KEY")
    LLM_MODEL:       str  = Field("gpt-4o-mini", env="LLM_MODEL")
    EMBEDDING_MODEL: str  = Field("text-embedding-3-small", env="EMBEDDING_MODEL")

    # ── RAG ───────────────────────────────────────────────────────────────────
    VECTORSTORE_DIR: str  = Field("data/vectorstore", env="VECTORSTORE_DIR")
    CHUNK_SIZE:      int  = Field(800,  env="CHUNK_SIZE")
    CHUNK_OVERLAP:   int  = Field(150,  env="CHUNK_OVERLAP")

    # ── Features ──────────────────────────────────────────────────────────────
    ENABLE_WEB_SEARCH: bool = Field(True, env="ENABLE_WEB_SEARCH")

    # ── Server ────────────────────────────────────────────────────────────────
    HOST: str = Field("0.0.0.0", env="HOST")
    PORT: int = Field(8000,      env="PORT")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
