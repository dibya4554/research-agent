"""
Tests for Research Assistant Agent API endpoints.
Run with: pytest tests/ -v
"""

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient
import io

from app.main import app

client = TestClient(app)


# ── Health Check ──────────────────────────────────────────────────────────────

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "research-agent"


# ── Query Endpoint ────────────────────────────────────────────────────────────

@patch("app.main.orchestrator")
def test_query_returns_answer(mock_orchestrator):
    """Query endpoint should return structured response."""
    mock_orchestrator.run = AsyncMock(return_value={
        "query": "What is RAG?",
        "answer": "RAG stands for Retrieval-Augmented Generation...",
        "sources": ["doc1.pdf (p.1)", "doc2.pdf (p.3)"],
        "summary": "RAG combines retrieval with generation.",
        "agent_trace": [
            "[Orchestrator] Pipeline started.",
            "[Planner] Decomposed into 2 sub-tasks.",
            "[Retriever] Retrieved 3 chunks.",
            "[Search] Found 2 web results.",
            "[Synthesis] Generated answer.",
            "[Summary] Executive summary generated.",
        ],
    })

    response = client.post("/query", json={
        "query": "What is RAG?",
        "max_sources": 5,
        "include_summary": True,
    })

    assert response.status_code == 200
    data = response.json()
    assert data["query"] == "What is RAG?"
    assert "answer" in data
    assert isinstance(data["sources"], list)
    assert isinstance(data["agent_trace"], list)


@patch("app.main.orchestrator")
def test_query_without_summary(mock_orchestrator):
    """Query with include_summary=False should return None summary."""
    mock_orchestrator.run = AsyncMock(return_value={
        "query": "Test query",
        "answer": "Test answer",
        "sources": [],
        "summary": None,
        "agent_trace": ["[Orchestrator] Pipeline started."],
    })

    response = client.post("/query", json={
        "query": "Test query",
        "include_summary": False,
    })

    assert response.status_code == 200
    assert response.json()["summary"] is None


@patch("app.main.orchestrator")
def test_query_internal_error(mock_orchestrator):
    """Query endpoint should return 500 on orchestrator failure."""
    mock_orchestrator.run = AsyncMock(side_effect=Exception("LLM timeout"))

    response = client.post("/query", json={"query": "Will this fail?"})
    assert response.status_code == 500


# ── Ingest Endpoint ───────────────────────────────────────────────────────────

@patch("app.main.ingestor")
def test_ingest_pdf(mock_ingestor):
    """Should ingest a PDF and return chunk count."""
    mock_ingestor.ingest.return_value = 12

    fake_pdf = io.BytesIO(b"%PDF-1.4 fake pdf content")
    response = client.post(
        "/ingest",
        files={"file": ("research_paper.pdf", fake_pdf, "application/pdf")},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["chunks_indexed"] == 12
    assert data["document_name"] == "research_paper.pdf"


@patch("app.main.ingestor")
def test_ingest_txt(mock_ingestor):
    """Should ingest a plain text file."""
    mock_ingestor.ingest.return_value = 5

    fake_txt = io.BytesIO(b"This is a research document about AI systems.")
    response = client.post(
        "/ingest",
        files={"file": ("notes.txt", fake_txt, "text/plain")},
    )

    assert response.status_code == 200
    assert response.json()["chunks_indexed"] == 5


def test_ingest_unsupported_format():
    """Unsupported file formats should return 400."""
    fake_file = io.BytesIO(b"some binary data")
    response = client.post(
        "/ingest",
        files={"file": ("data.xlsx", fake_file, "application/vnd.ms-excel")},
    )
    assert response.status_code == 400


# ── Vector Store ──────────────────────────────────────────────────────────────

@patch("app.main.ingestor")
def test_clear_vectorstore(mock_ingestor):
    """DELETE /vectorstore should clear the index."""
    response = client.delete("/vectorstore")
    assert response.status_code == 200
    mock_ingestor.clear.assert_called_once()
