"""
Unit tests for individual agents.
Run with: pytest tests/ -v
"""

import pytest
from unittest.mock import patch, MagicMock


# ── PlannerAgent ──────────────────────────────────────────────────────────────

class TestPlannerAgent:

    @patch("app.agents.planner.ChatOpenAI")
    def test_decompose_query(self, mock_llm_class):
        """Planner should decompose a query into sub-tasks."""
        from app.agents.planner import PlannerAgent

        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {
            "sub_tasks": ["What is LangChain?", "What are use cases of LangChain?"]
        }

        agent = PlannerAgent.__new__(PlannerAgent)
        agent.chain = mock_chain

        result = agent.run("Tell me about LangChain and its applications")
        assert isinstance(result, list)
        assert len(result) >= 1

    @patch("app.agents.planner.ChatOpenAI")
    def test_planner_fallback_on_error(self, mock_llm_class):
        """Planner should fall back to original query on LLM failure."""
        from app.agents.planner import PlannerAgent

        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = Exception("LLM unavailable")

        agent = PlannerAgent.__new__(PlannerAgent)
        agent.chain = mock_chain

        original_query = "What is machine learning?"
        result = agent.run(original_query)
        assert result == [original_query]


# ── RetrieverAgent ────────────────────────────────────────────────────────────

class TestRetrieverAgent:

    @patch("app.agents.retriever.VectorStoreManager")
    def test_retrieval_deduplicates(self, mock_vs_class):
        """Retriever should deduplicate chunks with same content."""
        from app.agents.retriever import RetrieverAgent
        from langchain_core.documents import Document

        duplicate_doc = Document(
            page_content="AI is transforming industries across the globe.",
            metadata={"source": "report.pdf", "page": 1},
        )

        mock_store = MagicMock()
        mock_store.similarity_search.return_value = [duplicate_doc, duplicate_doc]
        mock_vs = MagicMock()
        mock_vs.get_store.return_value = mock_store
        mock_vs_class.return_value = mock_vs

        agent = RetrieverAgent()
        chunks, sources = agent.run(["AI impact", "AI transformation"], max_sources=5)

        # Duplicates should be removed
        assert len(chunks) == 1

    @patch("app.agents.retriever.VectorStoreManager")
    def test_empty_vectorstore_returns_empty(self, mock_vs_class):
        """Should return empty lists when vector store has no documents."""
        from app.agents.retriever import RetrieverAgent

        mock_vs = MagicMock()
        mock_vs.get_store.return_value = None
        mock_vs_class.return_value = mock_vs

        agent = RetrieverAgent()
        chunks, sources = agent.run(["some query"])
        assert chunks == []
        assert sources == []


# ── SearchAgent ───────────────────────────────────────────────────────────────

class TestSearchAgent:

    @patch("app.agents.search.settings")
    def test_search_disabled(self, mock_settings):
        """SearchAgent should return empty list when disabled."""
        from app.agents.search import SearchAgent

        mock_settings.ENABLE_WEB_SEARCH = False
        agent = SearchAgent.__new__(SearchAgent)
        agent.enabled = False

        result = agent.run("test query")
        assert result == []

    @patch("app.agents.search.DuckDuckGoSearchRun")
    @patch("app.agents.search.settings")
    def test_search_returns_snippets(self, mock_settings, mock_ddg_class):
        """SearchAgent should parse snippets from DuckDuckGo results."""
        from app.agents.search import SearchAgent

        mock_settings.ENABLE_WEB_SEARCH = True
        mock_tool = MagicMock()
        mock_tool.run.return_value = "Result one\nResult two\nResult three"
        mock_ddg_class.return_value = mock_tool

        agent = SearchAgent()
        result = agent.run("AI research 2024")
        assert len(result) == 3


# ── SummaryAgent ──────────────────────────────────────────────────────────────

class TestSummaryAgent:

    @patch("app.agents.summary.ChatOpenAI")
    def test_short_answer_not_summarised(self, mock_llm_class):
        """Answers under 200 chars should be returned as-is."""
        from app.agents.summary import SummaryAgent

        agent = SummaryAgent.__new__(SummaryAgent)
        short_answer = "AI is artificial intelligence."
        result = agent.run(short_answer)
        assert result == short_answer
